from som_app import process_data

def run():
    process_data()

if __name__ == "__main__":
    run()