# SOM_unfinished
Code for ACTION SOM and CEA including input files.
run_modelCEA.py is the main file that executes other files in the right order.
Check that the paths to input files are correct in the initialize.py file.
Also, create folder "pupdated" in the working directory to export result excel files.
